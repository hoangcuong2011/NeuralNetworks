/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

/**
 *
 * @author hoangcuong2011
 */
public class Shuffle {

    double xs_shuffle[][][];
    double ys_shuffle[][][];

    public Shuffle(double xs_shuffle[][][], double ys_shuffle[][][]) {
        this.xs_shuffle = xs_shuffle;
        this.ys_shuffle = ys_shuffle;

    }
}
