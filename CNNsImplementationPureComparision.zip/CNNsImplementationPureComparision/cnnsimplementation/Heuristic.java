/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.util.Random;

/**
 *
 * @author hoangcuong2011
 */
public class Heuristic {

    int total_elements;
    int total_subsets;
    int subset_size;
    int maps[];
    
    public Heuristic(int e, int s, int substsize) {
        this.total_elements = e;
        this.total_subsets = s;
        this.subset_size = substsize;
    }
    public int[][] select() {
        Random r = new Random();                
        
        maps = new int[total_elements];
        for(int i = 0; i < maps.length; i++)
            maps[i] = i;
        
        int[][] indexes = new int[total_subsets][subset_size];
        int size = maps.length;
        for(int i = 0; i < total_subsets; i++) {
            for(int j = 0; j < subset_size; j++) {
                if(size>1) {
                    int rand = r.nextInt(size);
                    indexes[i][j] = maps[rand];
                    maps[rand] = maps[size-1];
                    size--;
                } else {
                    //phan tu 0
                    indexes[i][j] = maps[0];
                    maps = new int[total_elements];
                    for (int k = 0; k < maps.length; k++) {
                        maps[k] = k;
                    }
                    size = maps.length;
                }
                //System.out.println(indexes[i][j]+"~"+i+"~"+j);
            }
        }
        for(int i = 0; i < indexes.length; i++) {
            for(int j = 0; j < indexes[i].length; j++) {
                //System.out.print(" "+indexes[i][j]);
            }
            //System.out.println();
        }
        return indexes;
    }
    public static void main(String[] args) {
        Heuristic program = new Heuristic(50, 30, 25);
        program.select();
    }
}
