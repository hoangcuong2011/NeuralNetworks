
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import mnistreader.MNISTImageFile;
import mnistreader.MNISTLabelFile;

/**
 *
 * @author hoangcuong2011
 */
public class FeedForwardNeuralNetwork {


    public void CalculateSignalErrorsCrossEntropy(double hs[][][], double ys[][], double[][][] wxhs, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors, 
            double[][][] wxhs_dropout, double dropout_rate) {
        for (int layer = total_layers - 1; layer >= 1; layer--) {
            if (layer == total_layers - 1) {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        signalErrors[layer][trial][j] = hs_layer[trial][j]-ys[trial][j];
                    }
                }
            } else {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                double[][] wxhs_layer = wxhs[layer];

                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        double sum = 0.0;
                        for (int l = 0; l < hidden_units[layer + 1]; l++) {
                            sum += signalErrors[layer + 1][trial][l]
                                    * wxhs_layer[l][j]*wxhs_dropout[layer][l][j]*dropout_rate;
                        }
                        signalErrors[layer][trial][j] = sum * hs_layer[trial][j] * (1.0 - hs_layer[trial][j]);
                    }
                }
            }
        }
    }

    public void updateWeights(double hs[][][], double[][][] wxhs, double[][] biases, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors, double wxhs_update[][][],
            double[][] biases_update,
            double constant, double[][][] wxhs_dropout, double dropout_rate, 
            double[][][] momentum, double lambda) {
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            double[][] wxhs_layer = wxhs[layer];
            double hs_layer[][] = hs[layer];
            double wxhs_update_layer[][] = wxhs_update[layer];
            
            for (int i = 0; i < hidden_units[layer]; i++) {
                for (int j = 0; j < hidden_units[layer + 1]; j++) {
                    double d = 0.0;
                    for (int trial = 0; trial < trainingSamples; trial++) {
                        d += signalErrors[layer + 1][trial][j] * hs_layer[trial][i];
                    }
                    momentum[layer][i][j] = momentum[layer][i][j]*lambda+constant * d;
                    
                    if (wxhs_dropout[layer][j][i] > 0) {
                        wxhs_update_layer[j][i] = wxhs_layer[j][i] - momentum[layer][i][j];
                    } else {
                        wxhs_update_layer[j][i] = wxhs_layer[j][i];
                    }
                }
            }
        }
    }

    public double gradientChecking(int samples, double xs[][], double ys[][], int hidden_units[],
            int activationtype, int computationalTYPE, double[][][] hs) {
        int total_layers = hidden_units.length;
        double d = 0;
        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0.0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (ys[trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            d -= Math.log(hs[total_layers - 1][trial][max]);
        }
        return d;
    }

    public double getCrossEntropy(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;

        double d = 0;

        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0.0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (ys[trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            d -= Math.log(hs[total_layers - 1][trial][max]);
        }

        return d;

    }
    
    public double getClassificationError(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;


        double d1 = 0;
        double d2 = 0;
        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (hs[total_layers - 1][trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            try {
                if (ys[trial][max] != 1.0) {
                    d1++;
                }
                if (ys[trial][max] == 1.0) {
                    d2++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return d2/(d1+d2)*100;
    }

    public double[][][] computeForward(int total_layers, int trainingSamples, int hidden_units[],
            double xs_shuffle[][], double[][][] wxhs, double[][] bias,
            boolean dropout, double[][][] wxhs_dropout, double dropout_rate) {
        double hs[][][] = new double[total_layers][][];
        
        for (int k = 0; k < total_layers; k++) {
            if (k == 0) {
                hs[0] = new double[trainingSamples][hidden_units[0]];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[0]; j++) {
                        hs[0][trial][j] = xs_shuffle[trial][j];
                    }
                }
            } else {
                hs[k] = new double[trainingSamples][hidden_units[k]];
            }
        }

        for (int k = 1; k < total_layers; k++) {
            double[][] hs_layer_k = hs[k];
            if (k < (total_layers - 1)) {
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        if(dropout==false) {
                            hs_layer_k[trial][i] = NonLinearFunctions.sigmoid(
                                hs[k - 1][trial], wxhs[k - 1][i]);
                        } else {
                            hs_layer_k[trial][i] = NonLinearFunctions.sigmoid(
                                hs[k - 1][trial], 
                                NonLinearFunctions.matrixmul(wxhs[k - 1][i], wxhs_dropout[k - 1][i], dropout_rate));
                        }
                    }
                }
            } else {//The last layer
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs[k - 1][i].length; j++) {
                            if(dropout==false) {
                                hs_layer_k[trial][i] += hs[k - 1][trial][j] * wxhs[k - 1][i][j];
                            } else {
                                hs_layer_k[trial][i] += hs[k - 1][trial][j] * wxhs[k - 1][i][j]
                                        * wxhs_dropout[k - 1][i][j] * dropout_rate;
                            }
                        }
                    }
                    Utilities.computedSoftMaxwithTricks(hs_layer_k[trial]);
                }
            }
        }
        return hs;
    }

    public double generateNumber(double rangeMin, double rangeMax) {
        Random r = new Random();
        double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
        return randomValue;
    }
    Random random = new Random();   
    public boolean getRandomBoolean(double p) {
        return random.nextDouble() < p;
    }

    public double[][] deepCopy(double a[][]) {
        double[][] a_clone = new double[a.length][];
        for(int i = 0; i < a.length; i++) {
            a_clone[i] = new double[a[i].length];
            for(int j = 0; j < a[i].length; j++) {
                a_clone[i][j] = a[i][j];
            }
        }
        return a_clone;
    }    
    
    public Shuffle shuffle(int total_iterations, int minibatch, double[][] xs_training, double[][] ys_training) {
        Random r = new Random();
        double xs_shuffle[][][] = new double[total_iterations][minibatch][];
        double ys_shuffle[][][] = new double[total_iterations][minibatch][];

        double[][] xs_training_clone = deepCopy(xs_training);
        double[][] ys_training_clone = deepCopy(ys_training);

        int size = xs_training.length;
        for (int iteration = 0; iteration < total_iterations; iteration++) {
            int minsize = size > minibatch ? minibatch : size;
            for (int i = 0; i < minsize; i++) {
                int id = r.nextInt(size);
                xs_shuffle[iteration][i] = (xs_training_clone[id]);
                ys_shuffle[iteration][i] = (ys_training_clone[id]);
                if (size > 0) {
                    xs_training_clone[id] = xs_training_clone[size - 1];
                    ys_training_clone[id] = ys_training_clone[size - 1];
                    size--;
                }
            }
        }
        return new Shuffle(xs_shuffle, ys_shuffle);
    }

    

    public boolean[][][] Dropout_our(int total_layers, 
            int total_iterations, int hidden_units[], double dropout_keep_rate,
            boolean dropout) {
        boolean[][][] dropoutMatrices = new boolean[total_layers][total_iterations][];
        for (int i = 0; i < total_layers; i++) {
            dropoutMatrices[i] = new boolean[total_iterations][hidden_units[i]];
            for (int j = 0; j < total_iterations; j++) {
                for (int k = 0; k < hidden_units[i]; k++) {
                    dropoutMatrices[i][j][k] = true;
                    if (i == 0 || i == (total_layers - 1)) {
                        dropoutMatrices[i][j][k] = false; //I dont' do dropout for inputs and outputs
                    }
                }
            }
            if (i == 0 || i == (total_layers - 1)) {
                continue;
            }
            Heuristic program = new Heuristic(hidden_units[i],
                    total_iterations,
                    (int) (hidden_units[i] * dropout_keep_rate));
            int[][] outputs = program.select();
            for (int j = 0; j < total_iterations; j++) {
                for (int k = 0; k < outputs[j].length; k++) {
                    dropoutMatrices[i][j][outputs[j][k]] = false;//ok I don't do dropout
                }
            }
        }
        return dropoutMatrices;
    }
    
    
    public boolean[][][] Dropout_baseline(int total_layers, int total_iterations, int hidden_units[], 
            double dropout_rate,
            boolean dropout) {
        boolean[][][] dropoutMatrices = new boolean[total_layers][total_iterations][];
        
        for (int i = 0; i < total_layers; i++) {
            dropoutMatrices[i] = new boolean[total_iterations][hidden_units[i]];
        }
        
        
        for (int iteration = 0; iteration < total_iterations; iteration++) {    
            //sampling with replacement
            for (int k = 1; k < total_layers-1; k++) {
                for (int i = 0; i < hidden_units[k]; i++) {
                    boolean b = getRandomBoolean((1.0 - dropout_rate));
                    if(dropout==false)
                        b = false;
                    if(b==true) {
                        //I drop
                        dropoutMatrices[k][iteration][i] = true;
                    } else {
                        //No I don't
                        dropoutMatrices[k][iteration][i] = false;
                    }
                }
            }
        }
        return dropoutMatrices;
    }
    
    
    
    
    
    
    public boolean[][][] Dropout_baseline_my_modification(int total_layers, 
            int total_iterations, int hidden_units[], 
            double dropout_rate,
            boolean dropout) {
        boolean[][][] dropoutMatrices = new boolean[total_layers][total_iterations][];
        
        for (int i = 0; i < total_layers; i++) {
            dropoutMatrices[i] = new boolean[total_iterations][hidden_units[i]];
        }
        
        Random r = new Random();
        for (int iteration = 0; iteration < total_iterations; iteration++) {    
            //sampling with replacement
            for (int k = 1; k < total_layers-1; k++) {
                int[] index = new int[hidden_units[k]];
                for(int i= 0;i < index.length; i++) {
                    index[i] = i;
                    dropoutMatrices[k][iteration][i] = true;//Yes I drop
                }
                int cutoff = (int) (dropout_rate * hidden_units[k] );
                int size = index.length;
                int elements = 0;
                while(true) {
                    int id = r.nextInt(size);
                    dropoutMatrices[k][iteration][index[id]] = false;//i survied
                    elements++;
                    if(elements==cutoff)
                        break;
                    index[id] = index[size-1];
                    size--;
                }                
            }
        }
        return dropoutMatrices;
    }
    
    public void backpropagationNLayers(double xs_training[][], double ys_training[][], 
            int totaltrainingSamples,
            double xs_dev[][], double ys_dev[][], int totaldevSamples, 
            double xs_test[][], double ys_test[][], int totaltestSamples, 
            int hidden_units[], boolean dropout, double dropout_keep_rate) throws IOException {
        

        Random r = new Random();
        int total_layers = hidden_units.length;

        double lambda = 0.01;
        
        double wxhs_initialization[][][] = new double[total_layers - 1][][];
        double wxhs_dropout_baseline[][][] = new double[total_layers - 1][][];
        double wxhs_dropout_baseline_my_modification[][][] = new double[total_layers - 1][][];
        double wxhs_dropout_our[][][] = new double[total_layers - 1][][];
        
        
        Utilities.initializationWeights(wxhs_initialization, total_layers, hidden_units);
        
        double wxhs_baseline[][][] = Utilities.DeepCopy(wxhs_initialization);
        double wxhs_baseline_my_modification[][][] = Utilities.DeepCopy(wxhs_initialization);
        double wxhs_our[][][] = Utilities.DeepCopy(wxhs_initialization);
        
        
        Utilities.initializationWeights(wxhs_dropout_baseline, total_layers, hidden_units);
        Utilities.initializationWeights(wxhs_dropout_baseline_my_modification, total_layers, hidden_units);
        Utilities.initializationWeights(wxhs_dropout_our, total_layers, hidden_units);

        double biases_root[][] = new double[total_layers - 1][];
        if (1 == 1) {
            for (int k = 0; k < total_layers - 1; k++) {
                biases_root[k] = new double[hidden_units[k + 1]];
                for (int i = 0; i < biases_root[k].length; i++) {
                    biases_root[k][i] = r.nextDouble() - 0.5;
                }
            }
        }
        
        double[][] biases_baseline = deepCopy(biases_root);
        double[][] biases_baseline_my_modification = deepCopy(biases_root);
        double[][] biases_our = deepCopy(biases_root);
        double gamma = 0.5;
        
        double[][][] momentum_baseline = new double[total_layers][][];
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            momentum_baseline[layer] = new double[hidden_units[layer]][hidden_units[layer + 1]];
        }
        double[][][] momentum_baseline_my_modification = new double[total_layers][][];
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            momentum_baseline_my_modification[layer] = new double[hidden_units[layer]][hidden_units[layer + 1]];
        }
        
                
        double[][][] momentum_our = new double[total_layers][][];
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            momentum_our[layer] = new double[hidden_units[layer]][hidden_units[layer + 1]];
        }
        
        
        int minibatch = 20;
        double best_valid_baseline = -1;
        double best_test_baseline = -1;
        
        
        double best_valid_baseline_my_modification = -1;
        double best_test_baseline_my_modification = -1;
                
        double best_valid_our = -1;
        double best_test_our = -1;
        
        
        int total_iterations = (int) Math.ceil((double) xs_training.length / (double) minibatch);
        
        //int total_iterations = 20;

        for (int epoch = 0; epoch < 50; epoch++) {
            //shuffle
            Shuffle shuffle = shuffle(total_iterations, minibatch, xs_training, ys_training);
            boolean[][][] dropoutMatrices_baseline = 
                    Dropout_baseline(total_layers, total_iterations, hidden_units, dropout_keep_rate, dropout);
            
            
            boolean[][][] dropoutMatrices_baseline_my_modification = 
                    Dropout_baseline_my_modification(total_layers, total_iterations, hidden_units, dropout_keep_rate, dropout);
            
            boolean[][][] dropoutMatrices_our = 
                    Dropout_our(total_layers, total_iterations, hidden_units, dropout_keep_rate, dropout);

            for (int iteration = 0; iteration < total_iterations; iteration++) {                
                double constant = lambda / shuffle.xs_shuffle[iteration].length;
                
                
                for (int k = 1; k < total_layers; k++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs_baseline[k - 1][i].length; j++) {
                            if (dropoutMatrices_baseline[k - 1][iteration][j] == true
                                    || dropoutMatrices_baseline[k][iteration][i] == true) {
                                wxhs_dropout_baseline[k - 1][i][j] = 0.0;
                                if (dropout == false) {
                                    wxhs_dropout_baseline[k - 1][i][j] = 1.0;
                                }
                            } else {
                                wxhs_dropout_baseline[k - 1][i][j] = 1.0;
                            }
                        }
                    }
                }

                double hs_baseline[][][]
                        = computeForward(total_layers, minibatch, hidden_units, shuffle.xs_shuffle[iteration], 
                                wxhs_baseline, biases_baseline,
                                true, wxhs_dropout_baseline, dropout_keep_rate);

                double wxhs_update_baseline[][][] = Utilities.initializeEmptyArray(wxhs_baseline);
                double biases_update_baseline[][] = Utilities.initializeEmptyArray(biases_baseline);
                double signalErrors_baseline[][][] = new double[total_layers][][];

                CalculateSignalErrorsCrossEntropy(hs_baseline, shuffle.ys_shuffle[iteration], wxhs_baseline,
                        hidden_units, minibatch,
                        total_layers, signalErrors_baseline, wxhs_dropout_baseline, dropout_keep_rate);

                updateWeights(hs_baseline, wxhs_baseline, biases_baseline, hidden_units, minibatch, total_layers, signalErrors_baseline,
                        wxhs_update_baseline, biases_update_baseline, constant, wxhs_dropout_baseline,
                        dropout_keep_rate, momentum_baseline, gamma);
                wxhs_baseline = Utilities.DeepCopy(wxhs_update_baseline);
                biases_baseline = Utilities.DeepCopy(biases_update_baseline);
                
                
                
                for (int k = 1; k < total_layers; k++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs_baseline_my_modification[k - 1][i].length; j++) {
                            if (dropoutMatrices_baseline_my_modification[k - 1][iteration][j] == true
                                    || dropoutMatrices_baseline_my_modification[k][iteration][i] == true) {
                                wxhs_dropout_baseline_my_modification[k - 1][i][j] = 0.0;
                                if (dropout == false) {
                                    wxhs_dropout_baseline_my_modification[k - 1][i][j] = 1.0;
                                }
                            } else {
                                wxhs_dropout_baseline_my_modification[k - 1][i][j] = 1.0;
                            }
                        }
                    }
                }

                double hs_baseline_my_modification[][][]
                        = computeForward(total_layers, minibatch, hidden_units, shuffle.xs_shuffle[iteration], 
                                wxhs_baseline_my_modification, biases_baseline_my_modification,
                                true, wxhs_dropout_baseline_my_modification, dropout_keep_rate);

                double wxhs_update_baseline_my_modification[][][] 
                        = Utilities.initializeEmptyArray(wxhs_baseline_my_modification);
                double biases_update_baseline_my_modification[][] 
                        = Utilities.initializeEmptyArray(biases_baseline_my_modification);
                double signalErrors_baseline_my_modification[][][] = new double[total_layers][][];

                CalculateSignalErrorsCrossEntropy(hs_baseline_my_modification, 
                        shuffle.ys_shuffle[iteration], wxhs_baseline_my_modification,
                        hidden_units, minibatch,
                        total_layers, signalErrors_baseline_my_modification, 
                        wxhs_dropout_baseline_my_modification, dropout_keep_rate);

                updateWeights(hs_baseline_my_modification, wxhs_baseline_my_modification, 
                        biases_baseline_my_modification, hidden_units, 
                        minibatch, total_layers, signalErrors_baseline_my_modification,
                        wxhs_update_baseline_my_modification, biases_update_baseline_my_modification, 
                        constant, wxhs_dropout_baseline_my_modification,
                        dropout_keep_rate, momentum_baseline_my_modification, gamma);
                wxhs_baseline_my_modification = Utilities.DeepCopy(wxhs_update_baseline_my_modification);
                biases_baseline_my_modification = Utilities.DeepCopy(biases_update_baseline_my_modification);
                
                
                for (int k = 1; k < total_layers; k++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs_our[k - 1][i].length; j++) {
                            if (dropoutMatrices_our[k - 1][iteration][j] == true
                                    || dropoutMatrices_our[k][iteration][i] == true) {
                                wxhs_dropout_our[k - 1][i][j] = 0.0;
                                if (dropout == false) {
                                    wxhs_dropout_our[k - 1][i][j] = 1.0;
                                }
                            } else {
                                wxhs_dropout_our[k - 1][i][j] = 1.0;
                            }
                        }
                    }
                }

                double hs_our[][][]
                        = computeForward(total_layers, minibatch, hidden_units, 
                                shuffle.xs_shuffle[iteration], wxhs_our, biases_our,
                                true, wxhs_dropout_our, dropout_keep_rate);

                double wxhs_update_our[][][] = Utilities.initializeEmptyArray(wxhs_our);
                double biases_update_our[][] = Utilities.initializeEmptyArray(biases_our);
                double signalErrors_our[][][] = new double[total_layers][][];

                CalculateSignalErrorsCrossEntropy(hs_our, shuffle.ys_shuffle[iteration], wxhs_our,
                        hidden_units, minibatch,
                        total_layers, signalErrors_our, wxhs_dropout_our, dropout_keep_rate);

                updateWeights(hs_our, wxhs_our, biases_our, hidden_units, minibatch, total_layers, 
                        signalErrors_our,
                        wxhs_update_our, biases_update_our, constant, wxhs_dropout_our,
                        dropout_keep_rate, momentum_our, gamma);
                wxhs_our = Utilities.DeepCopy(wxhs_update_our);
                biases_our = Utilities.DeepCopy(biases_update_our);

                gamma = gamma + 0.1;
                if (gamma > 0.9) {
                    gamma = 0.9;
                }
            }

            //Utilities.writeWeights(wxhs, iteration);                
            System.out.println("Epoch: " + (epoch));
            double[][][] hs_baseline = computeForward(total_layers, totaldevSamples, hidden_units, xs_dev, 
                    wxhs_baseline, biases_baseline, false,
                    wxhs_dropout_baseline, dropout_keep_rate);
            double temp1 = getClassificationError(totaldevSamples, xs_dev, ys_dev, hidden_units, hs_baseline);
            

            
            if (temp1 > best_valid_baseline) {
                //---
                System.out.println("- For dev (Baseline)");            
                best_valid_baseline = temp1;
                System.out.println("Classification accuracy: " + temp1);
                System.out.println("- For test");
                hs_baseline = computeForward(total_layers, totaltestSamples, hidden_units, xs_test, 
                        wxhs_baseline, 
                        biases_baseline, false,
                        wxhs_dropout_baseline, dropout_keep_rate);

                double temp2 = getClassificationError(totaltestSamples, xs_test, ys_test, hidden_units, 
                        hs_baseline);
                
                System.out.println("Classification accuracy: " + temp2);

                best_test_baseline = temp2;
            }
            
            
            
            double[][][] hs_baseline_my_modification = computeForward(total_layers, totaldevSamples, 
                    hidden_units, xs_dev, 
                    wxhs_baseline_my_modification, biases_baseline_my_modification, false,
                    wxhs_dropout_baseline_my_modification, dropout_keep_rate);
            temp1 = getClassificationError(totaldevSamples, xs_dev, ys_dev, hidden_units, 
                    hs_baseline_my_modification);
            

            
            if (temp1 > best_valid_baseline_my_modification) {
                //---
                System.out.println("- For dev (Baseline Modification)");            
                best_valid_baseline_my_modification = temp1;
                System.out.println("Classification accuracy: " + temp1);
                System.out.println("- For test");
                hs_baseline_my_modification = computeForward(total_layers, totaltestSamples, hidden_units, xs_test, 
                        wxhs_baseline_my_modification, 
                        biases_baseline_my_modification, false,
                        wxhs_dropout_baseline_my_modification, dropout_keep_rate);

                double temp2 = getClassificationError(totaltestSamples, xs_test, ys_test, hidden_units, 
                        hs_baseline_my_modification);
                
                System.out.println("Classification accuracy: " + temp2);

                best_test_baseline_my_modification = temp2;
            }
            
            double[][][] hs_our = computeForward(total_layers, totaldevSamples, hidden_units, xs_dev, 
                    wxhs_our, biases_our, false,
                    wxhs_dropout_our, dropout_keep_rate);
            temp1 = getClassificationError(totaldevSamples, xs_dev, ys_dev, hidden_units, hs_our);
            

            
            if (temp1 > best_valid_our) {
                System.out.println("- For dev (Our)");
                best_valid_our = temp1;
                System.out.println("Classification accuracy: " + temp1);
                System.out.println("- For test");
                hs_our = computeForward(total_layers, totaltestSamples, hidden_units, xs_test, wxhs_our, 
                        biases_our, false,
                        wxhs_dropout_our, dropout_keep_rate);

                double temp2 = getClassificationError(totaltestSamples, xs_test, ys_test, 
                        hidden_units, hs_our);
                
                System.out.println("Classification accuracy: " + temp2);

                best_test_our = temp2;
            }

        }
        System.out.println("Best baseline: " + best_test_baseline + "~" + best_valid_baseline);
        
        System.out.println("Best baseline modification: " + best_test_baseline_my_modification + "~" + best_valid_baseline_my_modification);
                
        System.out.println("Best our: " + best_test_our + "~" + best_valid_our);
    }

    public void readData(String filename, int totalSize, double[][] myInputs, double[][] myOutputs) throws FileNotFoundException, IOException {
        BufferedReader buf = new BufferedReader(new FileReader(filename));
        String s = "";
        
        int count = 0;
        while ((s = buf.readLine()) != null) {
            String arr[] = s.trim().split(" ");
            double inputs[] = new double[arr.length - 1];
            double outputs[] = new double[10];
            for (int i = 0; i < arr.length - 1; i++) {
                inputs[i] = Integer.parseInt(arr[i]);
            }
            myInputs[count] = inputs;
            outputs[Integer.parseInt(arr[arr.length - 1])] = 1;
            myOutputs[count] = outputs;
            count++;
            if (count >= totalSize) {
                break;
            }
        }
        buf.close();
    }
    public static void main(String argss[]) throws IOException {
        FeedForwardNeuralNetwork program = new FeedForwardNeuralNetwork();
        
        int trainingIDs = 50000;
        int testIDs = 10000;
        int devIDs = 10000;
        double[][] TrainingXs = new double[trainingIDs][];
        double[][] TrainingYs = new double[trainingIDs][];
        double[][] TestXs = new double[testIDs][];
        double[][] TestYs = new double[testIDs][];
        double[][] DevXs = new double[devIDs][];
        double[][] DevYs = new double[devIDs][];

        program.readData("MNISTTraining", trainingIDs, TrainingXs, TrainingYs);
        program.readData("MNISTTest", testIDs, TestXs, TestYs);
        program.readData("MNISTDev", devIDs, DevXs, DevYs);

        double dropout_rate = 0.2;

        for (int k = 0; k < 10; k++) {
            int hidden_units[] = new int[3];
            hidden_units[0] = TrainingXs[0].length;
            hidden_units[1] = 70;
            hidden_units[2] = TrainingYs[0].length;//fixed

            program.backpropagationNLayers(TrainingXs, TrainingYs, trainingIDs, DevXs, DevYs, devIDs,
                    TestXs, TestYs, testIDs, hidden_units, true, dropout_rate);
            
            dropout_rate = dropout_rate;
        }
        if(1==1)
            return ;
                
    }
    
    
}
