/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.util.Random;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import jcuda.Pointer;
import jcuda.Sizeof;
import jcuda.jcublas.JCublas;
import static jcuda.jcublas.JCublas.cublasAlloc;
import static jcuda.jcublas.JCublas.cublasInit;
import static jcuda.runtime.JCuda.cudaSetDevice;
import mnistreader.MNISTImageFile;
import mnistreader.MNISTLabelFile;
import org.jblas.DoubleMatrix;

/**
 *
 * @author hoangcuong2011
 */
public class CNNsImplementation {

    double epsilon = 1e-5;

    public void CalculateSignalErrorsCrossEntropy(double hs[][][], double ys[][], double[][][] wxhs, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors) {
        for (int layer = total_layers - 1; layer >= 1; layer--) {
            if (layer == total_layers - 1) {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        signalErrors[layer][trial][j] = hs_layer[trial][j]-ys[trial][j];
                    }
                }
            } else {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                double[][] wxhs_layer = wxhs[layer];

                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        double sum = 0.0;
                        for (int l = 0; l < hidden_units[layer + 1]; l++) {
                            sum += signalErrors[layer + 1][trial][l]
                                    * wxhs_layer[l][j];
                        }
                        signalErrors[layer][trial][j] = sum* hs_layer[trial][j] * (1.0 - hs_layer[trial][j]);
                    }
                }
            }
        }
    }

    public void updateWeights(double hs[][][], double[][][] wxhs, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors, double wxhs_update[][][], double constant) {
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            double[][] wxhs_layer = wxhs[layer];
            double hs_layer[][] = hs[layer];
            double wxhs_update_layer[][] = wxhs_update[layer];
            for (int i = 0; i < hidden_units[layer]; i++) {
                for (int j = 0; j < hidden_units[layer + 1]; j++) {
                    double d = 0.0;
                    for (int trial = 0; trial < trainingSamples; trial++) {
                        d += signalErrors[layer + 1][trial][j] * hs_layer[trial][i];
                    }
                    wxhs_update_layer[j][i] = wxhs_layer[j][i] - constant * d;
                }
            }
        }
    }
    
    public double[][] leftOverErrors(double hs[][][], double[][][] wxhs, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors, double wxhs_update[][][],            
            double constant) {
        int layer = 0;
        double[][] leftOverGradients = new double[trainingSamples][hidden_units[layer]];        
        double[][] wxhs_layer = wxhs[layer];
        for (int i = 0; i < hidden_units[layer]; i++) {
            for (int trial = 0; trial < trainingSamples; trial++) {
                for (int j = 0; j < hidden_units[layer + 1]; j++) {
                    leftOverGradients[trial][i] += signalErrors[layer + 1][trial][j] * wxhs_layer[j][i];
                }
            }
        }
        return leftOverGradients;
    }

    public void gradientChecking(int hidden_units[], double[][][] hs, 
            int trainingSamples, double xs_shuffle[][], double ys_shuffle[][], double[][][] wxhs, double[][] bias,
            double[][][] signalErrors) throws IOException {
        
        int total_layers = hidden_units.length;
        
        /*whs a 3-D array: this represents the weights for connecting all neurals in all layers
        D1: number of layers (ALL layers - 1)
        D2: number of neurons in layer + 1
        D3: number of neurons of the layer current
         */
        double[][][] wxhs_cache = Utilities.DeepCopy(wxhs);

        //for(int layer = wxhs.length-1; layer <wxhs.length; layer++) {
        //for(int i = 0; i < wxhs[layer].length; i++) {
        //for(int j = 0; j < wxhs[layer][i].length; j++) {
        for (int layer = 0; layer < 1; layer++) {
            for (int i = 0; i < wxhs[layer].length; i++) {
                for (int j = 0; j < wxhs[layer][i].length; j++) {
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j] - 0.0001;
                    double hs_cache_1[][][] = computeForward(total_layers, trainingSamples, hidden_units, xs_shuffle, wxhs_cache);
                    double loss_1 = getCrossEntropy(trainingSamples, xs_shuffle, ys_shuffle, hidden_units, hs_cache_1);
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j] + 0.0001;
                    double hs_cache_2[][][] = computeForward(total_layers, trainingSamples, hidden_units, xs_shuffle, wxhs_cache);
                    double loss_2 = getCrossEntropy(trainingSamples, xs_shuffle, ys_shuffle, hidden_units, hs_cache_2);
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j];
                    /*hs_cache: a 3-D array: this represents all layers: inputs, hidden layers and outputs
                    D1: number of layers (ALL layers)
                    D2: number of training samples
                    D3: number of neurons of the layer
                     */
                    if (loss_2 - loss_1 > 0) {
                        double d = 0.0;
                        for (int trial = 0; trial < trainingSamples; trial++) {
                            d += signalErrors[layer + 1][trial][i] * hs[layer][trial][j];
                        }
                        
                        double fraction = Utilities.relativeComparison((loss_2 - loss_1) / (2 * 0.0001 * trainingSamples), d / trainingSamples);
                        if(fraction>0.001 && ((d / trainingSamples)>1e-7)) {
                            System.out.println("layer " + layer + "~" + i + "~" + j+"~"+wxhs[layer][i][j]+"~"+fraction);
                            System.out.println(((loss_2 - loss_1) / (2 * 0.0001 * trainingSamples))+"~"+(d / trainingSamples));
                        }
                    }
                }
            }
        }

        
    }

    public double getCrossEntropy(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;

        double d = 0;

        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0.0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (ys[trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            d -= Math.log(hs[total_layers - 1][trial][max]);
        }

        return d;

    }
    
    public double getClassificationError(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;


        double d1 = 0;
        double d2 = 0;
        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (hs[total_layers - 1][trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            try {
                if (ys[trial][max] != 1.0) {
                    d1++;
                }
                if (ys[trial][max] == 1.0) {
                    d2++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return d2/(d1+d2)*100;
    }

    public double[][][] computeForward(int total_layers, int trainingSamples, int hidden_units[],
            double xs_shuffle[][], double[][][] wxhs) {
        double hs[][][] = new double[total_layers][][];

        for (int k = 0; k < total_layers; k++) {
            if (k == 0) {
                hs[0] = new double[trainingSamples][hidden_units[0]];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[0]; j++) {
                        hs[0][trial][j] = xs_shuffle[trial][j];
                    }
                }
            } else {
                hs[k] = new double[trainingSamples][hidden_units[k]];
            }
        }

        for (int k = 1; k < total_layers; k++) {            
            if (k < (total_layers - 1)) {
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        hs[k][trial][i] = NonLinearFunctions.sigmoid(hs[k - 1][trial], wxhs[k - 1][i]);                        
                    }
                }
            } else {//The last layer
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs[k - 1][i].length; j++) {
                            hs[k][trial][i] += hs[k - 1][trial][j] * wxhs[k - 1][i][j];
                        }
                    }
                    Utilities.computedSoftMaxwithTricks(hs[k][trial]);

                }
            }
        }
        return hs;
    }

    public double generateNumber(double rangeMin, double rangeMax) {
        Random r = new Random();
        double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
        return randomValue;
    }

    public void Convo(double[][][] I, double[][][] F, double[][][][] C, int kernelSize, int squareImage) {
        //Convo operation for an Image I and a filter F
        for (int sample = 0; sample < I.length; sample++) {
            for (int filter = 0; filter < F.length; filter++) {
                for (int x = 0; x < squareImage; x++) {
                    for (int y = 0; y < squareImage; y++) {
                        for (int a = -2; a <= 2; a++) {
                            for (int b = -2; b <= 2; b++) {
                                double I_x_a_y_b = 0; //zero-padding
                                if (x + a >= 0 && y + b >= 0 && x+a <squareImage && y + b <squareImage) {
                                    I_x_a_y_b = I[sample][x + a][y + b];
                                }
                                C[sample][filter][x][y] += (I_x_a_y_b * F[filter][a-(-2)][b-(-2)]);//RLU
                            }
                        }
                    }
                }
            }
        }
        
        for (int sample = 0; sample < I.length; sample++) {
            for (int filter = 0; filter < F.length; filter++) {
                for (int x = 0; x < squareImage; x++) {
                    for (int y = 0; y < squareImage; y++) {
                        C[sample][filter][x][y] = NonLinearFunctions.sigmoid(C[sample][filter][x][y]);//RLU
                        if(C[sample][filter][x][y]>0) {
                            //System.out.println(C[sample][filter][x][y]);
                        }
                    }
                }
            }
        }

    }
    
    public void MaxPooling(double[][][][] I, int K, double[][][][] Ps) {
        //Max Pooling layer with an Image for K = 2
        for (int sample = 0; sample < I.length; sample++) {
            for (int filter = 0; filter < I[0].length; filter++) {
                for (int i = 0; i < Ps[0][0].length; i++) {
                    for (int j = 0; j < Ps[0][0][0].length; j++) {
                        int startX = i * K;
                        int startY = j * K;
                        for (int x = startX; x < startX + K; x++) {
                            for (int y = startY; y < startY + K; y++) {
                                if (Ps[sample][filter][i][j] < I[sample][filter][x][y]) {
                                    Ps[sample][filter][i][j] = I[sample][filter][x][y];
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public void backpropagationNLayerswithCNN(double xs_training[][][], double ys_training[][], int totaltrainingSamples,
            double xs_dev[][][], double ys_dev[][], int totaldevSamples, 
            double xs_test[][][], double ys_test[][], int totaltestSamples) throws IOException {
        /*xs_training is an array with 3 dimension: training samples, 28x28*/
        
        /*my CNN: 1 input layer, 1 convolution layer with 5 filters, each filter size is 3x3
        1 pooling layer, 1 vector output of CNN 1 hidden neural, 1 output with softmax
        Detail: 1 input layer with 3 dimension: training samples, 28x28
        
        */
        
        Random r = new Random();
        int minibatch = 20;
        double lambda = 0.01;
        int filter_size = 5;
        int filters = 20;
        int squareImage = 28; //an image is with 28 x 28

        /*A 4D dimension with:
        1. layer
        2. filter ID
        [3, 4]: matrix weights
         */
        
        double[][][] filterMatrices = new double[filters][filter_size][filter_size];
        for (int i = 0; i < filterMatrices.length; i++) {
            for (int j = 0; j < filter_size; j++) {
                for (int k = 0; k < filter_size; k++) {
                    filterMatrices[i][j][k] = r.nextDouble() - 0.5;
                }
            }
        }
        double constant = lambda / minibatch;
        
        int pooling_size = 2;
        int sizePoolingOutputs = squareImage/pooling_size;
                
        int MLP_hiddenunits = 4;
        int[] MLPhidden_units = new int[MLP_hiddenunits];
        double[][] newTraininginMLPs = new double[minibatch][filters*sizePoolingOutputs*sizePoolingOutputs];
        MLPhidden_units[0] = filters*sizePoolingOutputs*sizePoolingOutputs;
        MLPhidden_units[1] = 50; //number of hidde neurons
        MLPhidden_units[2] = 50; //number of hidde neurons        
        MLPhidden_units[3] = 10; //number of outputs, which is 10 for MNIST
        int total_layers = MLPhidden_units.length;
        
        double wxhsMLP[][][] = new double[MLP_hiddenunits - 1][][];
        /*a 3-D array: this represents the weights for connecting all neurals in all layers
        D1: number of layers (ALL layers - 1)
        D2: number of neurons in layer + 1
        D3: number of neurons of the layer current
         */

        Utilities.initializationWeights(wxhsMLP, MLP_hiddenunits, MLPhidden_units);

        

        for (int iteration = 0; iteration < 5000000; iteration++) {

            //sampling with replacement
            double xs_shuffle[][][] = new double[minibatch][][];
            double ys_shuffle[][] = new double[minibatch][];
            for (int i = 0; i < minibatch; i++) {
                int id = r.nextInt(totaltrainingSamples); //sampling with replacement
                //int id = i; //use all the data (given that minibatch is as the same as the training data
                xs_shuffle[i] = (xs_training[id]);
                ys_shuffle[i] = (ys_training[id]);
            }

            double[][][][] C_1 = new double[minibatch][filters][squareImage][squareImage];
            /*C1: A 4D dimension with:
            1. training sample
            2. filter ID
            [3, 4]: matrix weights
             */

            double[][][][] Ps_1 = new double[minibatch][filters][sizePoolingOutputs][sizePoolingOutputs];//pooling outputs
            /*C1: A 4D dimension with:
            1. training sample
            2. filter ID
            [3, 4]: matrix values from pooling
             */

            Convo(xs_shuffle, filterMatrices, C_1, filter_size, squareImage);
            MaxPooling(C_1, pooling_size, Ps_1);
            Utilities.squashArray(Ps_1, newTraininginMLPs);

            double hs[][][] = computeForward(total_layers, minibatch, MLPhidden_units, newTraininginMLPs, wxhsMLP);
            /*a 3-D array: this represents all layers: inputs, hidden layers and outputs
        D1: number of layers (ALL layers)
        D2: number of training samples
        D3: number of neurons of the layer
            
            
             */

            if ((iteration + 1) % 1000 == 0) {
                Utilities.writeWeights(wxhsMLP, iteration);
                System.out.println("Iteration: " + (iteration + 1) + "~" + wxhsMLP[0][0][0]);
                System.out.println("- For training data");
                System.out.println("loss function (cross entropy): " + getCrossEntropy(minibatch, newTraininginMLPs, ys_shuffle, MLPhidden_units, hs));
                System.out.println("classification accuracy: " + getClassificationError(minibatch, newTraininginMLPs, ys_shuffle, MLPhidden_units, hs));

                double[][][][] C = new double[totaldevSamples][filters][squareImage][squareImage];
                /*C1: A 4D dimension with:
            1. training sample
            2. filter ID
            [3, 4]: matrix weights
                 */

                double[][][][] Ps = new double[totaldevSamples][filters][sizePoolingOutputs][sizePoolingOutputs];//pooling outputs
                /*C1: A 4D dimension with:
            1. training sample
            2. filter ID
            [3, 4]: matrix values from pooling
                 */

                Convo(xs_dev, filterMatrices, C, filter_size, squareImage);
                MaxPooling(C, pooling_size, Ps);
                double[][] newTraininginMLPsDev = new double[totaldevSamples][filters * sizePoolingOutputs * sizePoolingOutputs];
                Utilities.squashArray(Ps, newTraininginMLPsDev);
                double hsDev[][][] = computeForward(total_layers, totaldevSamples, MLPhidden_units, newTraininginMLPsDev, wxhsMLP);
                System.out.println("- For dev data");
                System.out.println("loss function (cross entropy): " + getCrossEntropy(totaldevSamples, newTraininginMLPsDev, ys_dev, MLPhidden_units, hsDev));
                System.out.println("classification accuracy: " + getClassificationError(totaldevSamples, newTraininginMLPsDev, ys_dev, MLPhidden_units, hsDev));
            }

            double wxhs_update[][][] = Utilities.initializeEmptyArray(wxhsMLP);
            double signalErrors[][][] = new double[total_layers][][];

            CalculateSignalErrorsCrossEntropy(hs, ys_shuffle, wxhsMLP, MLPhidden_units, minibatch, total_layers, signalErrors);
            updateWeights(hs, wxhsMLP, MLPhidden_units, minibatch, total_layers, signalErrors,
                    wxhs_update, constant);
            double[][] leftOverGradients = leftOverErrors(hs, wxhsMLP, MLPhidden_units, minibatch, total_layers, signalErrors,
                    wxhs_update, constant);

            wxhsMLP = Utilities.DeepCopy(wxhs_update);

            //leftOverGradients: a 2-D matrices with one dimension: training samples and the another one: [hidden_units[layer]];
            double[][][][] leftOverGradientsin4D = Utilities.convertFlatto4DArray(leftOverGradients, filters);
            //continue backpropagation

            double[][][][] leftOverGradientsin4DBeforePooling
                    = new double[minibatch][filters][squareImage][squareImage];
            for (int sample = 0; sample < minibatch; sample++) {
                for (int filter = 0; filter < filters; filter++) {
                    for (int i = 0; i < leftOverGradientsin4D[sample][filter].length; i++) {
                        for (int j = 0; j < leftOverGradientsin4D[sample][filter][0].length; j++) {
                            int startX = i * pooling_size;
                            int startY = j * pooling_size;
                            for (int x = startX; x < startX + pooling_size; x++) {
                                for (int y = startY; y < startY + pooling_size; y++) {
                                    if (Ps_1[sample][filter][i][j] != C_1[sample][filter][x][y]) {
                                        leftOverGradientsin4DBeforePooling[sample][filter][x][y] = 0.0;
                                        continue;
                                    }
                                    leftOverGradientsin4DBeforePooling[sample][filter][x][y] 
                                                = Ps_1[sample][filter][i][j]*C_1[sample][filter][x][y]*(1.0-C_1[sample][filter][x][y]);

                                }
                            }
                        }
                    }
                }
            }
            for (int filter = 0; filter < filters; filter++) {
                double[][] cache = new double[filter_size][filter_size];
                for (int sample = 0; sample < minibatch; sample++) {
                    for (int x = 0; x < squareImage; x++) {
                        for (int y = 0; y < squareImage; y++) {
                            if (leftOverGradientsin4DBeforePooling[sample][filter][x][y] > 0) {
                                int startX = x - 2; //filter_size
                                int startY = y - 2; //filter_size
                                for (int i = startX; i < startX + filter_size; i++) {
                                    for (int j = startY; j < startY + filter_size; j++) {
                                        if (i >= 0 && j >= 0 && i <squareImage && j < squareImage) {
                                            if (xs_shuffle[sample][i][j] > 0) {
                                                cache[i-startX][j-startY] += leftOverGradientsin4DBeforePooling[sample][filter][x][y] * xs_shuffle[sample][i][j];
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                for (int j = 0; j < filterMatrices[0].length; j++) {
                    for (int k = 0; k < filterMatrices[0].length; k++) {
                        if (cache[j][k] > 0.0) {
                            filterMatrices[filter][j][k] = filterMatrices[filter][j][k] - constant * cache[j][k];
                        }
                    }
                }
            }
        }
    }

    public double[][] backpropagationMLPNLayers(double xs_shuffle[][], double ys_shuffle[][],
            int hidden_units[], double wxhsMLP[][][], int iteration, int minibatch, double lambda, double constant) throws IOException {

        
        int total_layers = hidden_units.length;
        
        
        if ((iteration + 1) % 1 == 0) {
            Utilities.writeWeights(wxhsMLP, iteration);
            System.out.println("Iteration: " + (iteration + 1));
            System.out.println("- For training data");
            double hs[][][] = computeForward(total_layers, minibatch, hidden_units, xs_shuffle, wxhsMLP);
            System.out.println("loss function (cross entropy): " + getCrossEntropy(minibatch, xs_shuffle, ys_shuffle, hidden_units, hs));
            System.out.println("classification accuracy: " + getClassificationError(minibatch, xs_shuffle, ys_shuffle, hidden_units, hs));

        }
        
        double hs[][][] = computeForward(total_layers, minibatch, hidden_units, xs_shuffle, wxhsMLP);
        /*a 3-D array: this represents all layers: inputs, hidden layers and outputs
        D1: number of layers (ALL layers)
        D2: number of training samples
        D3: number of neurons of the layer
         */

        double wxhs_update[][][] = Utilities.initializeEmptyArray(wxhsMLP);
        double signalErrors[][][] = new double[total_layers][][];

        CalculateSignalErrorsCrossEntropy(hs, ys_shuffle, wxhsMLP, hidden_units, minibatch, total_layers, signalErrors);
        /*if ((iteration + 1) % 1 == 0) {
                gradientChecking(hidden_units, hs, minibatch, xs_shuffle, ys_shuffle, wxhs, biases, signalErrors);
            }*/

        updateWeights(hs, wxhsMLP, hidden_units, minibatch, total_layers, signalErrors,
                wxhs_update, constant);
        double[][] leftOverGradients = leftOverErrors(hs, wxhsMLP, hidden_units, minibatch, total_layers, signalErrors,
                wxhs_update, constant);
        
        wxhsMLP = Utilities.DeepCopy(wxhs_update);
        
        return leftOverGradients;
    }
    
    public static void main(String argss[]) throws IOException {
        CNNsImplementation program = new CNNsImplementation();
        int trainingIDs = 50000;
        int testIDs = 10000;
        int devIDs = 10000;
        double[][] TrainingXs = new double[trainingIDs][];
        double[][] TrainingYs = new double[trainingIDs][];
        double[][] TestXs = new double[testIDs][];
        double[][] TestYs = new double[testIDs][];
        double[][] DevXs = new double[devIDs][];
        double[][] DevYs = new double[devIDs][];

        System.out.println("Converting ...");
        Utilities.readData("MNISTTraining", trainingIDs, TrainingXs, TrainingYs);
        Utilities.readData("MNISTTest", testIDs, TestXs, TestYs);
        Utilities.readData("MNISTDev", devIDs, DevXs, DevYs);
        System.out.println("Done");

        
        double[][][] newTraininginCNNXs = Utilities.convertFlatto3DArray(TrainingXs);
        double[][][] newDevinCNNXs = Utilities.convertFlatto3DArray(DevXs);
        double[][][] newTestinCNNXs = Utilities.convertFlatto3DArray(TestXs);

        program.backpropagationNLayerswithCNN(newTraininginCNNXs, TrainingYs, trainingIDs, newDevinCNNXs, DevYs, devIDs, 
                newTestinCNNXs, TestYs, testIDs);

    }
}
