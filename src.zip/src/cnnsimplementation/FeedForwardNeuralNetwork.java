
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import jcuda.Pointer;
import jcuda.Sizeof;
import jcuda.jcublas.JCublas;
import static jcuda.jcublas.JCublas.cublasAlloc;
import static jcuda.jcublas.JCublas.cublasInit;
import static jcuda.runtime.JCuda.cudaSetDevice;
import mnistreader.MNISTImageFile;
import mnistreader.MNISTLabelFile;
import org.jblas.DoubleMatrix;

/**
 *
 * @author hoangcuong2011
 */
public class FeedForwardNeuralNetwork {


    public void CalculateSignalErrorsCrossEntropy(double hs[][][], double ys[][], double[][][] wxhs, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors) {
        for (int layer = total_layers - 1; layer >= 1; layer--) {
            if (layer == total_layers - 1) {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        signalErrors[layer][trial][j] = hs_layer[trial][j]-ys[trial][j];
                    }
                }
            } else {
                signalErrors[layer] = new double[trainingSamples][hidden_units[layer]];
                double[][] hs_layer = hs[layer];
                double[][] wxhs_layer = wxhs[layer];

                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[layer]; j++) {
                        double sum = 0.0;
                        for (int l = 0; l < hidden_units[layer + 1]; l++) {
                            sum += signalErrors[layer + 1][trial][l]
                                    * wxhs_layer[l][j];
                        }
                        signalErrors[layer][trial][j] = sum * hs_layer[trial][j] * (1.0 - hs_layer[trial][j]);
                    }
                }
            }
        }
    }

    public void updateWeights(double hs[][][], double[][][] wxhs, double[][] biases, int hidden_units[],
            int trainingSamples, int total_layers, double[][][] signalErrors, double wxhs_update[][][],
            double[][] biases_update,
            double constant) {
        for (int layer = total_layers - 2; layer >= 0; layer--) {
            double[][] wxhs_layer = wxhs[layer];
            double hs_layer[][] = hs[layer];
            double wxhs_update_layer[][] = wxhs_update[layer];
            for (int i = 0; i < hidden_units[layer]; i++) {
                for (int j = 0; j < hidden_units[layer + 1]; j++) {
                    double d = 0.0;
                    for (int trial = 0; trial < trainingSamples; trial++) {
                        d += signalErrors[layer + 1][trial][j] * hs_layer[trial][i];
                    }
                    wxhs_update_layer[j][i] = wxhs_layer[j][i] - constant * d;
                }
            }
        }
    }

    public void gradientChecking(int hidden_units[], double[][][] hs, 
            int trainingSamples, double xs_shuffle[][], double ys_shuffle[][], double[][][] wxhs, double[][] bias,
            double[][][] signalErrors) throws IOException {
        
        int total_layers = hidden_units.length;
        
        /*whs a 3-D array: this represents the weights for connecting all neurals in all layers
        D1: number of layers (ALL layers - 1)
        D2: number of neurons in layer + 1
        D3: number of neurons of the layer current
         */
        double[][][] wxhs_cache = Utilities.DeepCopy(wxhs);

        //for(int layer = wxhs.length-1; layer <wxhs.length; layer++) {
        //for(int i = 0; i < wxhs[layer].length; i++) {
        //for(int j = 0; j < wxhs[layer][i].length; j++) {
        for (int layer = 0; layer < 1; layer++) {
            for (int i = 0; i < wxhs[layer].length; i++) {
                for (int j = 0; j < wxhs[layer][i].length; j++) {
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j] - 0.0001;
                    double hs_cache_1[][][] = computeForward(total_layers, trainingSamples, hidden_units, xs_shuffle, wxhs_cache, bias);
                    double loss_1 = getCrossEntropy(trainingSamples, xs_shuffle, ys_shuffle, hidden_units, hs_cache_1);
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j] + 0.0001;
                    double hs_cache_2[][][] = computeForward(total_layers, trainingSamples, hidden_units, xs_shuffle, wxhs_cache, bias);
                    double loss_2 = getCrossEntropy(trainingSamples, xs_shuffle, ys_shuffle, hidden_units, hs_cache_2);
                    wxhs_cache[layer][i][j] = wxhs[layer][i][j];
                    /*hs_cache: a 3-D array: this represents all layers: inputs, hidden layers and outputs
                    D1: number of layers (ALL layers)
                    D2: number of training samples
                    D3: number of neurons of the layer
                     */
                    if (loss_2 - loss_1 > 0) {
                        double d = 0.0;
                        for (int trial = 0; trial < trainingSamples; trial++) {
                            d += signalErrors[layer + 1][trial][i] * hs[layer][trial][j];
                        }
                        
                        double fraction = Utilities.relativeComparison((loss_2 - loss_1) / (2 * 0.0001 * trainingSamples), d / trainingSamples);
                        if(fraction>0.001 && ((d / trainingSamples)>1e-7)) {
                            System.out.println("layer " + layer + "~" + i + "~" + j+"~"+wxhs[layer][i][j]+"~"+fraction);
                            System.out.println(((loss_2 - loss_1) / (2 * 0.0001 * trainingSamples))+"~"+(d / trainingSamples));
                        }
                    }
                }
            }
        }

        
    }

    public double getCrossEntropy(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;

        double d = 0;

        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0.0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (ys[trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            d -= Math.log(hs[total_layers - 1][trial][max]);
        }

        return d;

    }
    
    public double getClassificationError(int samples, double xs[][], double ys[][], int hidden_units[], double[][][] hs) throws IOException {
        int total_layers = hidden_units.length;


        double d1 = 0;
        double d2 = 0;
        for (int trial = 0; trial < samples; trial++) {
            int max = -1;
            double dmax = 0;
            for (int i = 0; i < hidden_units[total_layers - 1]; i++) {
                if (hs[total_layers - 1][trial][i] > dmax) {
                    dmax = hs[total_layers - 1][trial][i];
                    max = i;
                }
            }
            try {
                if (ys[trial][max] != 1.0) {
                    d1++;
                }
                if (ys[trial][max] == 1.0) {
                    d2++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return d2/(d1+d2)*100;
    }

    public double[][][] computeForward(int total_layers, int trainingSamples, int hidden_units[],
            double xs_shuffle[][], double[][][] wxhs, double[][] bias) {
        double hs[][][] = new double[total_layers][][];

        for (int k = 0; k < total_layers; k++) {
            if (k == 0) {
                hs[0] = new double[trainingSamples][hidden_units[0]];
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int j = 0; j < hidden_units[0]; j++) {
                        hs[0][trial][j] = xs_shuffle[trial][j];
                    }
                }
            } else {
                hs[k] = new double[trainingSamples][hidden_units[k]];
            }
        }

        for (int k = 1; k < total_layers; k++) {
            double[][] hs_layer_k = hs[k];
            if (k < (total_layers - 1)) {
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        hs_layer_k[trial][i] = NonLinearFunctions.sigmoid(hs[k - 1][trial], wxhs[k - 1][i]);
                    }
                }
            } else {//The last layer
                for (int trial = 0; trial < trainingSamples; trial++) {
                    for (int i = 0; i < hidden_units[k]; i++) {
                        for (int j = 0; j < wxhs[k - 1][i].length; j++) {
                            hs_layer_k[trial][i] += hs[k - 1][trial][j] * wxhs[k - 1][i][j];
                        }
                    }
                    Utilities.computedSoftMaxwithTricks(hs_layer_k[trial]);
                }
            }
        }
        return hs;
    }

    public double generateNumber(double rangeMin, double rangeMax) {
        Random r = new Random();
        double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
        return randomValue;
    }

    public void backpropagationNLayers(double xs_training[][], double ys_training[][], int totaltrainingSamples,
            double xs_dev[][], double ys_dev[][], int totaldevSamples, 
            double xs_test[][], double ys_test[][], int totaltestSamples, int hidden_units[]) throws IOException {
        
        Random r = new Random();
        int total_layers = hidden_units.length;

        double lambda = 0.01;

        double wxhs[][][] = new double[total_layers - 1][][];
        /*a 3-D array: this represents the weights for connecting all neurals in all layers
        D1: number of layers (ALL layers - 1)
        D2: number of neurons in layer + 1
        D3: number of neurons of the layer current
         */
        Utilities.initializationWeightsRLU(wxhs, total_layers, hidden_units);

        double biases[][] = new double[total_layers - 1][];
        if (1 == 1) {
            for (int k = 0; k < total_layers - 1; k++) {
                biases[k] = new double[hidden_units[k + 1]];
                for (int i = 0; i < biases[k].length; i++) {
                    biases[k][i] = r.nextDouble() - 0.5;
                }
            }
        }
        int minibatch = 20;
        for (int iteration = 0; iteration < 5000000; iteration++) {
            
            
            //sampling with replacement
            double xs_shuffle[][] = new double[minibatch][];
            double ys_shuffle[][] = new double[minibatch][];
            for (int i = 0; i < minibatch; i++) {
                int id = r.nextInt(totaltrainingSamples); //sampling with replacement
                //int id = i; //use all the data (given that minibatch is as the same as the training data
                xs_shuffle[i] = (xs_training[id]);
                ys_shuffle[i] = (ys_training[id]);
            }
            
            double constant = lambda / minibatch;

            if ((iteration + 1) % 10000 == 0) {

                Utilities.writeWeights(wxhs, iteration);                
                System.out.println("Iteration: "+(iteration+1));
                System.out.println("- For training data");
                double hs[][][] = computeForward(total_layers, minibatch, hidden_units, xs_shuffle, wxhs, biases);
                System.out.println("loss function (cross entropy): "+getCrossEntropy(minibatch, xs_shuffle, ys_shuffle, hidden_units, hs));                
                System.out.println("classification accuracy: "+getClassificationError(minibatch, xs_shuffle, ys_shuffle, hidden_units, hs));
                
                //---
                System.out.println("- For dev");
                hs = computeForward(total_layers, totaldevSamples, hidden_units, xs_dev, wxhs, biases);
                System.out.println("Classification accuracy: "+getClassificationError(totaldevSamples, xs_dev, ys_dev, hidden_units, hs));
                
                System.out.println("- For test");
                hs = computeForward(total_layers, totaltestSamples, hidden_units, xs_test, wxhs, biases);
                System.out.println("Classification accuracy: "+getClassificationError(totaltestSamples, xs_test, ys_test, hidden_units, hs));

            }
            double hs[][][] = computeForward(total_layers, minibatch, hidden_units, xs_shuffle, wxhs, biases);
            /*a 3-D array: this represents all layers: inputs, hidden layers and outputs
        D1: number of layers (ALL layers)
        D2: number of training samples
        D3: number of neurons of the layer
             */

            double wxhs_update[][][] = Utilities.initializeEmptyArray(wxhs);
            double biases_update[][] = Utilities.initializeEmptyArray(biases);
            double signalErrors[][][] = new double[total_layers][][];

            CalculateSignalErrorsCrossEntropy(hs, ys_shuffle, wxhs, hidden_units, minibatch, total_layers, signalErrors);
            /*if ((iteration + 1) % 1 == 0) {
                gradientChecking(hidden_units, hs, minibatch, xs_shuffle, ys_shuffle, wxhs, biases, signalErrors);
            }*/

            updateWeights(hs, wxhs, biases, hidden_units, minibatch, total_layers, signalErrors,
                    wxhs_update, biases_update, constant);
            wxhs = Utilities.DeepCopy(wxhs_update);
            biases = Utilities.DeepCopy(biases_update);

        }
    }

    public static void main(String argss[]) throws IOException {
        FeedForwardNeuralNetwork program = new FeedForwardNeuralNetwork();
        int trainingIDs = 50000;
        int testIDs = 100;
        int devIDs = 100;
        double[][] TrainingXs = new double[trainingIDs][];
        double[][] TrainingYs = new double[trainingIDs][];
        double[][] TestXs = new double[testIDs][];
        double[][] TestYs = new double[testIDs][];
        double[][] DevXs = new double[devIDs][];
        double[][] DevYs = new double[devIDs][];

       
        Utilities.readData("MNISTTraining", trainingIDs, TrainingXs, TrainingYs);
        Utilities.readData("MNISTTest", testIDs, TestXs, TestYs);
        Utilities.readData("MNISTDev", devIDs, DevXs, DevYs);

        int hidden_units[] = new int[4];
        hidden_units[0] = TrainingXs[0].length;
        hidden_units[1] = 100;
        hidden_units[2] = 100;
        hidden_units[3] = TrainingYs[0].length;//fixed

        program.backpropagationNLayers(TrainingXs, TrainingYs, trainingIDs, DevXs, DevYs, devIDs, 
                TestXs, TestYs, testIDs, hidden_units);

    }
}
