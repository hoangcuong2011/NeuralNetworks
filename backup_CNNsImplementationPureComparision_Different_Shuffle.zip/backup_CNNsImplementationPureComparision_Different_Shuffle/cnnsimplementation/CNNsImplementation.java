/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.util.Random;

/**
 *
 * @author hoangcuong2011
 */
public class CNNsImplementation {

    /**
     * @param args the command line arguments
     */
    
    public static double computeFunction(double x) {
        return 3*x*x*x;
    }
    public static double getMax(double a, double b) {
        return a>b?a:b;
    }
    public static void gradientDescentCheck() {
        //y = 3x^3 -> partial y/partial x = 9x^2
        Random r = new Random();
        for(int i = 0; i < 10; i++) {
            double x = r.nextDouble();            
            double h = 0.00001;
            double deviative1 = (computeFunction(x+h)-computeFunction(x))/h;
            double deviative2 = (computeFunction(x+h)-computeFunction(x-h))/h/2.0;
            double deviativeAnalatic = (9*(x+h)*(x+h));
            //System.out.println(deviative1+"~"+deviative2+"~"+deviativeAnalatic);
            System.out.println((Math.abs(deviative1-deviativeAnalatic)/getMax(deviative1, deviativeAnalatic))+"~"+
                    (Math.abs(deviative2-deviativeAnalatic)/getMax(deviative2, deviativeAnalatic)));
            
        }
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        gradientDescentCheck();
    }
    
}
