/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

/**
 *
 * @author hoangcuong2011
 */
public class NonLinearFunctions {
    public static double softmax(double xs[], double ws[]) {
        double d = 0.0;
        for (int i = 0; i < ws.length; i++) {
            d += ws[i] * xs[i];
        }        
        return Math.exp(d);
    }
    
    public static double[] matrixmul(double xs[], double ws[], double constant) {
        double outputs[] = new double[xs.length];
        for (int i = 0; i < ws.length; i++) {
            outputs[i] = ws[i] * xs[i]*constant;
        }
        return outputs;
    }
    public static double sigmoid(double xs[], double ws[]) {
        double d = 0.0;
        for (int i = 0; i < ws.length; i++) {
            d += ws[i] * xs[i];
        }
        d *= -1.0;
        d = Math.exp(d);
        d += 1.0;
        d = 1.0 / d;
        return d;
    }

    public static double sigmoid(double d) {
        d *= -1.0;
        d = Math.exp(d);
        d += 1.0;
        d = 1.0 / d;
        return d;
    }

    public static double tanh(double xs[], double ws[]) {
        double d = 0.0;
        for (int i = 0; i < ws.length; i++) {
            d += ws[i] * xs[i];
        }
        //System.out.println(d);
        return Math.tanh(d);
    }

    public static double RLU(double xs[], double ws[]) {
        double d = 0.0;
        for (int i = 0; i < ws.length; i++) {
            d += ws[i] * xs[i];
        }
        //System.out.println(d);
        if (d >= 0) {
            return d;
        } else {
            return 0;
        }
    }
    
    public static double RLU(double d) {
        if (d >= 0) {
            return d;
        } else {
            return 0;
        }
    }
}
