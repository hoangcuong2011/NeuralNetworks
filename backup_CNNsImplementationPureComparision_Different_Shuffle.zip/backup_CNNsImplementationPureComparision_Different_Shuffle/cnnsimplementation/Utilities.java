/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cnnsimplementation;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import mnistreader.MNISTImageFile;
import mnistreader.MNISTLabelFile;

/**
 *
 * @author hoangcuong2011
 */
public class Utilities {
    
    /**
     *
     * @param A A[m.n]
     * @return A Transpose [n,m]
     */
    public static double[][] Transpose(double[][] A) {
        int m = A.length;
        int n = A[0].length;
        double[][] aT = new double[n][m];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                aT[j][i] = A[i][j];
            }
        }
        return aT;
    }

    public static double[] To1D(double[][] A) {
        int m = A.length;
        int n = A[0].length;
        double[] v = new double[m * n];
        int count = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                v[count] = A[i][j];
                count += 1;
            }
        }
        return v;
    }

    /**
     *
     * @param v vector representation of A(m,n)
     * (A(0,0)...A(0,n))...(A(m,0)...A(m,n))
     * @param m
     * @param n
     * @return A(m,n)
     */
    public static double[][] To2D(double[] v, int m, int n) {
        double[][] A = new double[m][n];
        int count = 0;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                A[i][j] = v[count];
                count += 1;
            }
        }
        return A;
    }

    public static void writeWeights(double[][][] wxhs, int iteration) throws IOException {
        FileWriter fi_w = new FileWriter("weights_" + (iteration + 1));

        for (int k = 0; k < wxhs.length; k++) {
            for (int i = 0; i < wxhs[k].length; i++) {
                for (int j = 0; j < wxhs[k][i].length; j++) {
                    fi_w.write(wxhs[k][i][j] + "\n");
                }
            }
        }
        fi_w.close();
    }
    public static void computedSoftMaxwithTricks(double[] probs) {
        /*input: an array of probabilities; output: softmax*/
        double max = -1;
        double[] outputs = new double[probs.length];
        double sum = 0;       
        for(int i = 0; i < probs.length; i++) {
            if(probs[i]>max)
                max = probs[i];
        }
        
        for(int i = 0; i < probs.length; i++) {
            outputs[i] = Math.exp(probs[i]-max);
            sum+=outputs[i];
        }
        for(int i = 0; i < probs.length; i++) {
            probs[i] = outputs[i] / sum;
        }
    }
    public static void initializationWeights(double wxhs[][][], int total_layers, int hidden_units[]) {
        Random r = new Random();
        for (int k = 0; k < total_layers - 1; k++) {
            wxhs[k] = new double[hidden_units[k + 1]][hidden_units[k]];
            for (int i = 0; i < wxhs[k].length; i++) {
                for (int j = 0; j < wxhs[k][0].length; j++) {
                    wxhs[k][i][j] = r.nextDouble() - 0.5;
                }
            }
        }
    }
    
    public static double[][][] initializeEmptyArray(double A[][][]) {
        //Goal: Creating a new array that has the same size as A.
        double newA[][][] = new double[A.length][][];
        for (int k = 0; k < A.length; k++) {
            newA[k] = new double[A[k].length][A[k][0].length];
        }
        return newA;
    }

    public static double[][] initializeEmptyArray(double A[][]) {
        //Goal: Creating a new array that has the same size as A.
        double newA[][] = new double[A.length][];
        for (int k = 0; k < A.length; k++) {
            newA[k] = new double[A[k].length];
        }
        return newA;
    }

    
    public static double[][][] DeepCopy(double A[][][]) {
        //Goal: Creating a deep copy for an 3D Array A.
        double newA[][][] = new double[A.length][][];
        for (int k = 0; k < A.length; k++) {
            newA[k] = new double[A[k].length][A[k][0].length];
            for (int i = 0; i < newA[k].length; i++) {
                for (int j = 0; j < newA[k][0].length; j++) {
                    newA[k][i][j] = A[k][i][j];
                }
            }
        }
        return newA;
    }
    
    public static double[][] DeepCopy(double A[][]) {
        //Goal: Creating a deep copy for an 3D Array A.
        double newA[][] = new double[A.length][];
        for (int k = 0; k < A.length; k++) {
            newA[k] = new double[A[k].length];
            for (int i = 0; i < newA[k].length; i++) {
                newA[k][i] = A[k][i];
            }
        }
        return newA;
    }
    
    public static double[] DeepCopy(double A[]) {
        //Goal: Creating a deep copy for an 3D Array A.
        double newA[] = new double[A.length];
        for (int k = 0; k < A.length; k++) {
            newA[k] = A[k];
        }
        return newA;
    }
    
    public static void printMatrix(double[][] matrix) {
        for (double[] line : matrix) {
            int i = 0;
            StringBuilder sb = new StringBuilder(matrix.length);
            for (double number : line) {
                if (i != 0) {
                    sb.append("\t");
                } else {
                    i++;
                }
                sb.append(number);
            }
            System.out.println(sb.toString());
        }
    }
    
    
    public static void convertBinaryFilestoTextFiles() throws IOException {
        if (1 == 1) {
            //write all files into bundle ...
            String[] args = "MNIST/train-images.idx3-ubyte MNIST/train-labels.idx1-ubyte".split(" ");
            MNISTImageFile imgF = null;
            MNISTLabelFile lblF = null;

            try {
                imgF = new MNISTImageFile(args[0], "r");
                lblF = new MNISTLabelFile(args[1], "r");
            } catch (FileNotFoundException e) {
                System.err.println("File not found: " + e);
                System.exit(0);
            } catch (IOException e) {
                System.err.println("IO Exception: " + e);
                System.exit(0);
            }

            FileWriter MNISTWriter = new FileWriter("MNISTTraining");
            for (int index = 1; index <= 60000; index++) {

                imgF.setCurr((index));
                lblF.setCurr((index));
                int[][] dat = imgF.data();
                int value = lblF.data();
                for (int i = 0; i < dat.length; i++) {
                    for (int j = 0; j < dat.length; j++) {
                        MNISTWriter.write("" + dat[i][j]);
                        MNISTWriter.write(" ");
                    }
                }
                MNISTWriter.write("" + value);
                MNISTWriter.write("\n");
            }
            MNISTWriter.close();

        }

        if (1 == 1) {
            //write all files into bundle ...
            String[] args = "MNIST/t10k-images.idx3-ubyte MNIST/t10k-labels.idx1-ubyte".split(" ");
            MNISTImageFile imgF = null;
            MNISTLabelFile lblF = null;

            try {
                imgF = new MNISTImageFile(args[0], "r");
                lblF = new MNISTLabelFile(args[1], "r");
            } catch (FileNotFoundException e) {
                System.err.println("File not found: " + e);
                System.exit(0);
            } catch (IOException e) {
                System.err.println("IO Exception: " + e);
                System.exit(0);
            }

            FileWriter MNISTWriter = new FileWriter("MNISTTest");
            for (int index = 1; index <= 10000; index++) {

                imgF.setCurr((index));
                lblF.setCurr((index));
                int[][] dat = imgF.data();
                int value = lblF.data();
                for (int i = 0; i < dat.length; i++) {
                    for (int j = 0; j < dat.length; j++) {
                        MNISTWriter.write("" + dat[i][j]);
                        MNISTWriter.write(" ");
                    }
                }
                MNISTWriter.write("" + value);
                MNISTWriter.write("\n");
            }
            MNISTWriter.close();

        }

    }

    
}
